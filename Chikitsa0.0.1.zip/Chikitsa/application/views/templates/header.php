<html>
<head>
	<title>Chikitsa - Patient Management System</title>
        
        <script src="<?=base_url()?>js/jquery-1.6.js"></script>
        
        <script type="text/javascript" src="<?=base_url()?>js/jquery.1.5.2.min.js"></script>
        <script type="text/javascript" src="<?=base_url()?>js/jquery.1.8.2.min.js"></script>
        <script src="<?=base_url()?>js/date.js"></script>
        <script src="<?=base_url()?>js/jquery.datePicker.js"></script>
        <script src="<?=base_url()?>js/jquery.timepicker.js"></script>
        
        <script src="<?=base_url()?>js/common.js"></script>
        
        <link rel="stylesheet" href='<?=base_url()?>css/datePicker.css' type="text/css"/>
        <link rel="stylesheet" href='<?=base_url()?>css/style.css' type="text/css"/>
        <link rel="stylesheet" href='<?=base_url()?>js/jquery.timepicker.css' type="text/css"/>
</head>
<body>
    <div class="header">
        <h1>Chikitsa</h1>
        <h3>Patient Management System</h3>
    </div>
    
        

    