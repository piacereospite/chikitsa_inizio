<ul class="nav">
<li><a href="<?php echo site_url("patient/index"); ?>">Patients</a></li>
<li><a href="<?php echo site_url("appointment/index"); ?>">Appointments</a></li>
<li><a href="<?php echo site_url("settings/edit"); ?>">Settings</a></li>
</ul>
