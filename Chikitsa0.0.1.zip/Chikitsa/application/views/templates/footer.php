<div class="footer">
<strong>&copy; 2012 Sanskruti Technologies</strong>	
</div>
</body>
</html>